## Relevant articles:

- [A Guide to Spring Mobile](http://www.baeldung.com/spring-mobile)

